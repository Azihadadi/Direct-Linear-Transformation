clc;
clear all;
close all;

%% making a scene
one = ones(1,100);
data = load('data.mat');
p3D = data.X;
p3D = [p3D;one];
p3D = round(p3D,4);

%% defining a camera
cam = CentralCamera('default','pose',transl(0,0,-10)*trotz(0)*troty(0));
toolbox_calib = cam.C;
p2D = toolbox_calib*p3D;
p2D = round(p2D./p2D(3,:),4);

%% plotting the camera and the scene
cam.plot_camera;
plot_sphere(p3D,0.1);
title('3-D model without noise')

%% estimating the calibration matrix
est_calib = getCameraMatrix(p2D,p3D);

%% scale factor
scale = round(toolbox_calib./est_calib,4);
p2Ds = (toolbox_calib./(scale+0.00000001))*p3D;

%% showing result
figure
res_p2D=est_calib*p3D;
hold on
plot_point(res_p2D(1:2,:), 'bo', 'MarkerFaceColor', 'g');
plot_point(p2Ds(1:2,:), 'bx', 'MarkerFaceColor', 'r');
title('2-D image by DLT and corresponding points by scale factor');
hold off;
disp('camera p martix:');
toolbox_calib
disp('estimted p martix by DLT:');
est_calib

%% generating a Gaussian noise and adding to the 3-D points
variance = 0.05;
mean = 0;
noise = sqrt(variance)*randn(size(p3D(1:3,:))) + mean;
p3Dn = round(p3D(1:3,:) + noise,4);
p3Dn = [p3Dn;one];

%% plotting the camera and the scene
figure
cam2 = CentralCamera('default','pose',transl(0,0,-10)*trotz(0)*troty(0));
cam2.plot_camera;
plot_sphere(p3Dn(1:3,:),0.1);
title('3-D model with noise')

%% project into 2D image plane
p2Dn=est_calib*p3Dn;
figure 
hold on
plot_point(p2Dn(1:2,:), 'bo', 'MarkerFaceColor', 'g');
plot_point(p2Ds(1:2,:), 'bx', 'MarkerFaceColor', 'r');
title('2-D image by DLT and corresponding points in the presence of noise');

hold off;

%% error analysis in presence of a Gaussian noise 
for i=1:100
    variance = i*0.005;
    mean = 0;
    noise = sqrt(variance)*randn(size(p3D(1:3,:))) + mean;
    p3Dn = round(p3D(1:3,:) + noise,4);
    p3Dn = [p3Dn;one];
    p2Dn=est_calib*p3Dn;
    e(i)=abs(sum(sum(p2Dn-res_p2D)));
end
figure
plot([1:100]*0.005,e)
    xlabel('variance of noise');
    ylabel('accumulative error');



